# Scott Williams
# 7/7/2025
# P4LAB1b
# Draw initials in python using turtle

#Import the library
import turtle

win = turtle.Screen()  
t = turtle.Turtle()

# add some display options
t.pensize(6)            
t.pencolor("purple")    
t.shape("arrow")

#If this assignment had to be done using loops, I couldnt figure it out
#I considered alternating if/else statements to determine angular changes
#But I couldnt figure out how to make that work for the 'S'

# Draw the S
t.forward(50)      
t.left(90)
t.forward(50)      
t.left(90)
t.forward(50)      
t.right(90)
t.forward(50)      
t.right(90)
t.forward(50)     

#Penup and move to the right to a new start position
t.penup()
t.goto(100, 100)
t.pendown()

# Draw the W
t.right(75)
t.forward(100)    
t.left(150)
t.forward(100)      
t.right(150)
t.forward(100)     
t.left(150)
t.forward(100)


#Wait for user to close window

win.mainloop()
