# Scott Williams
# 7/7/2025
# P4LAB1a
# Using loops within Python to draw geometric shapes using turtle

#Import the library
import turtle

win = turtle.Screen()  
t = turtle.Turtle()

# add some display options
t.pensize(6)            
t.pencolor("purple")    
t.shape("arrow")

#variable to initialize the loop
i = 0

#while loop that will only work for this example
#square = 4 sides and triangle = 3 sides so when both shapes are fully dawn, i=7

while i < 7:
    #Starting with i=0, so the first four sides of the square will be drawn
    if i < 4:
        t.forward(200)
        t.left(90)
    #Once the square is drawn, i=4, and now the else statement executes
    else:
        t.forward(150)
        t.left(120)
    #Once the 3 sides of the triangle are drawn, the loop terminates as now i=7
    i += 1


    
#Wait for user to close window

win.mainloop()
